--
-- PostgreSQL database dump
--


-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.7

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--



--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


SET default_table_access_method = heap;

--
-- Name: celebrities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.celebrities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    image_path text NOT NULL,
    elo_rating numeric(10,2) DEFAULT 1200.00 NOT NULL,
    games_played integer DEFAULT 0 NOT NULL,
    wins integer DEFAULT 0 NOT NULL,
    losses integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.celebrities REPLICA IDENTITY FULL;


--
-- Name: matchups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.matchups (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    winner_id uuid NOT NULL,
    loser_id uuid NOT NULL,
    winner_previous_elo numeric(10,2) NOT NULL,
    loser_previous_elo numeric(10,2) NOT NULL,
    winner_new_elo numeric(10,2) NOT NULL,
    loser_new_elo numeric(10,2) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: celebrities celebrities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.celebrities
    ADD CONSTRAINT celebrities_pkey PRIMARY KEY (id);


--
-- Name: matchups matchups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matchups
    ADD CONSTRAINT matchups_pkey PRIMARY KEY (id);


--
-- Name: idx_celebrities_elo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_celebrities_elo ON public.celebrities USING btree (elo_rating DESC);


--
-- Name: idx_celebrities_games; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_celebrities_games ON public.celebrities USING btree (games_played DESC);


--
-- Name: idx_matchups_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_matchups_created ON public.matchups USING btree (created_at DESC);


--
-- Name: celebrities update_celebrities_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_celebrities_updated_at BEFORE UPDATE ON public.celebrities FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: matchups matchups_loser_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matchups
    ADD CONSTRAINT matchups_loser_id_fkey FOREIGN KEY (loser_id) REFERENCES public.celebrities(id) ON DELETE CASCADE;


--
-- Name: matchups matchups_winner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matchups
    ADD CONSTRAINT matchups_winner_id_fkey FOREIGN KEY (winner_id) REFERENCES public.celebrities(id) ON DELETE CASCADE;


--
-- Name: celebrities Anyone can view celebrities; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Anyone can view celebrities" ON public.celebrities FOR SELECT USING (true);


--
-- Name: matchups Anyone can view matchups; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Anyone can view matchups" ON public.matchups FOR SELECT USING (true);


--
-- Name: celebrities; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.celebrities ENABLE ROW LEVEL SECURITY;

--
-- Name: matchups; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.matchups ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--


